package uk.ac.city.acnm249.moviesearch;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by totoobi on 25/11/2015.
 */


public class OMDBDatabase extends SQLiteOpenHelper {

    public static final String DB_NAME = "omdb.db";
    public static final int DB_VERSION = 1;
    public static final String TABLE_NAME ="omdb";
    public static final String COL_ID = "id";
    public static final String COL_JSON ="json";




    public OMDBDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String TABLE_CREATE = "CREATE TABLE omdb (id TEXT, json TEXT)";
        db.execSQL(TABLE_CREATE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    // Adding new data to the table
    public void insertData(String keyword, String result){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();

        cv.put ("id", keyword);
        cv.put("json", result);

        db.insert (TABLE_NAME, null, cv);
        db.close();
    }


    public String getResults(String keyword){

        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT json FROM " + TABLE_NAME + " WHERE id='" + keyword + "'";
        Cursor cursor =db.rawQuery(query, null);
        String result = null;


        if (cursor.moveToNext()){
            result = cursor.getString(0);
        }

        cursor.close();
        db.close();
        return result;
    }


}

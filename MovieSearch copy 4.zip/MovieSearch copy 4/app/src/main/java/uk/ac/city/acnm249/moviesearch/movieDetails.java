package uk.ac.city.acnm249.moviesearch;

import android.content.Intent;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class movieDetails extends AppCompatActivity {
private String title;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        Intent intent = getIntent();
        String keyworditem = intent.getExtras().getString("item");
        int gethyphen = keyworditem.lastIndexOf("-");


        title = keyworditem.substring(0, gethyphen - 1);
        title = title.replaceAll("\\s", "+");

        String year = keyworditem.substring(gethyphen + 2, keyworditem.length());


        String json = runSearch(title, year);



            TextView textViewTitle = (TextView) findViewById(R.id.textViewTitle);
            TextView textViewGenre = (TextView) findViewById(R.id.textViewMovieGenre);
            TextView textViewActors = (TextView) findViewById(R.id.textViewMovieActors);
            TextView textViewPlot = (TextView) findViewById(R.id.textViewMoviePlot);


            try {

                JSONObject jsonObject = new JSONObject(json);


                textViewTitle.setText(jsonObject.getString("Title"));
                textViewGenre.setText("Genre: " + jsonObject.getString("Genre"));
                textViewActors.setText("Actors: " + jsonObject.getString("Actors"));
                textViewPlot.setText("Plot: " + jsonObject.getString("Plot"));


            } catch (JSONException e) {
                e.printStackTrace();
            }
    }





    private String runSearch(String title, String year) {


        title = title.replaceAll("//s", "+");
        //year = year.replaceAll("//s", "+");
        String jsonResult = null;

        try {


            URL url = new URL("http://www.omdbapi.com/?t=" + title + "&y" + year + "&plot=short&r=json");
            Log.d("URL", url.toString());

            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

            InputStream input = httpURLConnection.getInputStream();

            Scanner scanner = new Scanner(input, "UTF-8").useDelimiter("\\A");
            jsonResult = scanner.hasNext() ? scanner.next() : "";

        } catch (Exception e) {
            e.printStackTrace();

        }
        return jsonResult;
    }

    public void goToResults (View view) {

            Intent goBack = new Intent(this, Results.class);
        goBack.putExtra("movieTitle",title);

        startActivity(goBack);

    }
}



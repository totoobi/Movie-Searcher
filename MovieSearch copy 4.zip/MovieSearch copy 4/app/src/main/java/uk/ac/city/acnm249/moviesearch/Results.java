package uk.ac.city.acnm249.moviesearch;

import android.content.Intent;
import android.net.Uri;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;



import static android.widget.AdapterView.*;


public class Results extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        String keyword = getIntent().getExtras().getString("movieTitle");
        keyword = keyword.replaceAll("\\s", "+");



        OMDBDatabase db = new OMDBDatabase(this);

        String jsonResult = db.getResults(keyword);

       /// Adding toast messages to alert the user of how the app will search the data

        Toast.makeText(getApplicationContext(), "SEARCHING:-)",
                Toast.LENGTH_LONG).show();

        if (jsonResult == null){
            Toast.makeText(getApplicationContext(), "CHECKING :-)",
                    Toast.LENGTH_LONG).show();
            jsonResult = runSearch(keyword);
            db.insertData(keyword, jsonResult);
        }
        ArrayList<String> searchResults = getValuesFromJSON(jsonResult);

        ListView listview = (ListView) findViewById(R.id.listView);

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, searchResults);

        listview.setAdapter(arrayAdapter);


        listview.setOnItemClickListener(new OnItemClickListener() {
            @Override

            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item =((TextView)view).getText().toString();
                Intent intent = new Intent(Results.this, movieDetails.class);
                intent.putExtra("item", item);
                startActivity(intent);
            }
        });


        }




    private String runSearch(String keyword) {

        String jsonResult = null;

        try {
            URL url = new URL("http://www.omdbapi.com/?s=" + keyword);

            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

            InputStream input = httpURLConnection.getInputStream();

            Scanner scanner = new Scanner(input, "UTF-8").useDelimiter("\\A");
            jsonResult = scanner.hasNext() ? scanner.next() : "";

        }catch (Exception e) {
            e.printStackTrace();
        }
        return jsonResult;

    }

    private ArrayList<String> getValuesFromJSON(String jsonResult){
         ArrayList<String> results = new ArrayList<>();

         try{
             JSONObject jsonObject = new JSONObject(jsonResult);
             JSONArray jsonArray = jsonObject.getJSONArray("Search");
             for (int i=0; i<jsonArray.length(); i++){
                 JSONObject result =jsonArray.getJSONObject(i);
                 StringBuilder sb = new StringBuilder();
                 sb.append(result.getString("Title"));
                 sb.append(" - ");
                 sb.append(result.getString("Year"));
                 results.add(sb.toString());

             }

         }catch (Exception e){
             e.printStackTrace();

         }
         return results;

     }


    public void goToSearch (View view) {
        Intent intent = new Intent(this, search.class);
        startActivity(intent);
    }

}


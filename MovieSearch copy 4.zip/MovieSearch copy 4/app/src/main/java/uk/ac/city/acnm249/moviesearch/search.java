package uk.ac.city.acnm249.moviesearch;

import android.content.Intent;
import android.net.Uri;
import android.os.Parcelable;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class search extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }

    public void goToResults (View view){
        EditText movieTitle = (EditText) findViewById(R.id.movie_title);
        String title = movieTitle.getText().toString();
        Intent intent = new Intent(this, Results.class);
        intent.putExtra("movieTitle", title);
        startActivity(intent);

    }

    public void goToWebpage(View view){
        goToUrl("http://www.imdb.com/calendar/?region=gb");
    }

    private void goToUrl (String url) {
        Uri uriUrl = Uri.parse(url);
        Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
        startActivity(launchBrowser);
    }

}
/// For my additional content, i changed the icon of the app to a magnifying glass by saving a png file and inserting it as a new image asset into the drawable file under "res".
/// I also made Toast pop-up message that is called when the user searches for a movie
///the toast works by saying,"searching" if the user has made the search before, or "Checking" if they haven't
///this is because it works with the database to notifies the user and was also a way to ensure that it is adding to the database.
/// I have also added in an extra button called "button2", this button opens the browser app to the imdb website to show the user all the latest movies.
/// I have also made a feature that finds out the extra information
/// for this i made the listview of the array list clickable and to start another activity, for this i had to research on "onClickListeners", and also on how to convert json details into a textView
/// the activity is called movieDetails , this woks by tacking the "title" and the "year" from the clicked search to run the omdb api, to get the string details of the specific movie.
///then it takes the strings from the url and displays them in a textView
/// i also created anothe back button that can take you back to the search page., this works by linking the button to another method i created.
///Prior to these changes i have already completed task 1,2 and 3 of the coursework summary.

